/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    xilinxcorelib_ver_m_00000000001358910285_1256727229_init();
    xilinxcorelib_ver_m_00000000001687936702_1862936372_init();
    xilinxcorelib_ver_m_00000000000277421008_3429841031_init();
    xilinxcorelib_ver_m_00000000001603977570_1307194084_init();
    work_m_00000000002489990758_2499224580_init();
    work_m_00000000003175977924_1342587579_init();
    work_m_00000000003035775930_0273213086_init();
    work_m_00000000000086159481_0886308060_init();
    work_m_00000000002309490655_3508565487_init();
    work_m_00000000000422578369_1970878987_init();
    work_m_00000000002730698511_3464244632_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000002730698511_3464244632");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
