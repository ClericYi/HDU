/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/caopeng/Desktop/shiyan13/shiyan13/shiyan13.v";
static unsigned int ng1[] = {0U, 0U};
static unsigned int ng2[] = {14U, 0U};
static unsigned int ng3[] = {15U, 0U};
static unsigned int ng4[] = {1U, 0U};



static void Always_33_0(char *t0)
{
    char t13[8];
    char t19[8];
    char t24[8];
    char t66[8];
    char t90[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    char *t38;
    char *t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    int t48;
    int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    char *t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t67;
    char *t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    char *t81;
    char *t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    char *t88;
    char *t89;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    char *t96;
    char *t97;

LAB0:    t1 = (t0 + 3872U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(33, ng0);
    t2 = (t0 + 4192);
    *((int *)t2) = 1;
    t3 = (t0 + 3904);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(34, ng0);
    t4 = (t0 + 1752U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB5;

LAB6:    xsi_set_current_line(39, ng0);
    t2 = (t0 + 1912U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB12;

LAB10:    if (*((unsigned int *)t2) == 0)
        goto LAB9;

LAB11:    t4 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t4) = 1;

LAB12:    t5 = (t13 + 4);
    t14 = *((unsigned int *)t5);
    t15 = (~(t14));
    t16 = *((unsigned int *)t13);
    t17 = (t16 & t15);
    t18 = (t17 != 0);
    if (t18 > 0)
        goto LAB13;

LAB14:    xsi_set_current_line(44, ng0);
    t2 = (t0 + 2232U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB17;

LAB18:    if (*((unsigned int *)t2) != 0)
        goto LAB19;

LAB20:    t5 = (t13 + 4);
    t14 = *((unsigned int *)t13);
    t15 = *((unsigned int *)t5);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB21;

LAB22:    memcpy(t24, t13, 8);

LAB23:    t56 = (t24 + 4);
    t57 = *((unsigned int *)t56);
    t58 = (~(t57));
    t59 = *((unsigned int *)t24);
    t60 = (t59 & t58);
    t61 = (t60 != 0);
    if (t61 > 0)
        goto LAB31;

LAB32:    xsi_set_current_line(57, ng0);
    t2 = (t0 + 2232U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB47;

LAB45:    if (*((unsigned int *)t2) == 0)
        goto LAB44;

LAB46:    t4 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t4) = 1;

LAB47:    memset(t19, 0, 8);
    t5 = (t13 + 4);
    t14 = *((unsigned int *)t5);
    t15 = (~(t14));
    t16 = *((unsigned int *)t13);
    t17 = (t16 & t15);
    t18 = (t17 & 1U);
    if (t18 != 0)
        goto LAB48;

LAB49:    if (*((unsigned int *)t5) != 0)
        goto LAB50;

LAB51:    t12 = (t19 + 4);
    t20 = *((unsigned int *)t19);
    t21 = *((unsigned int *)t12);
    t22 = (t20 || t21);
    if (t22 > 0)
        goto LAB52;

LAB53:    memcpy(t66, t19, 8);

LAB54:    t63 = (t66 + 4);
    t69 = *((unsigned int *)t63);
    t70 = (~(t69));
    t71 = *((unsigned int *)t66);
    t72 = (t71 & t70);
    t73 = (t72 != 0);
    if (t73 > 0)
        goto LAB62;

LAB63:
LAB64:
LAB33:
LAB15:
LAB7:    goto LAB2;

LAB5:    xsi_set_current_line(35, ng0);

LAB8:    xsi_set_current_line(36, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 2952);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 4, 0LL);
    xsi_set_current_line(37, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2792);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    goto LAB7;

LAB9:    *((unsigned int *)t13) = 1;
    goto LAB12;

LAB13:    xsi_set_current_line(40, ng0);

LAB16:    xsi_set_current_line(41, ng0);
    t11 = (t0 + 2072U);
    t12 = *((char **)t11);
    t11 = (t0 + 2952);
    xsi_vlogvar_wait_assign_value(t11, t12, 0, 0, 4, 0LL);
    xsi_set_current_line(42, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2792);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    goto LAB15;

LAB17:    *((unsigned int *)t13) = 1;
    goto LAB20;

LAB19:    t4 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t4) = 1;
    goto LAB20;

LAB21:    t11 = (t0 + 2392U);
    t12 = *((char **)t11);
    memset(t19, 0, 8);
    t11 = (t12 + 4);
    t17 = *((unsigned int *)t11);
    t18 = (~(t17));
    t20 = *((unsigned int *)t12);
    t21 = (t20 & t18);
    t22 = (t21 & 1U);
    if (t22 != 0)
        goto LAB24;

LAB25:    if (*((unsigned int *)t11) != 0)
        goto LAB26;

LAB27:    t25 = *((unsigned int *)t13);
    t26 = *((unsigned int *)t19);
    t27 = (t25 & t26);
    *((unsigned int *)t24) = t27;
    t28 = (t13 + 4);
    t29 = (t19 + 4);
    t30 = (t24 + 4);
    t31 = *((unsigned int *)t28);
    t32 = *((unsigned int *)t29);
    t33 = (t31 | t32);
    *((unsigned int *)t30) = t33;
    t34 = *((unsigned int *)t30);
    t35 = (t34 != 0);
    if (t35 == 1)
        goto LAB28;

LAB29:
LAB30:    goto LAB23;

LAB24:    *((unsigned int *)t19) = 1;
    goto LAB27;

LAB26:    t23 = (t19 + 4);
    *((unsigned int *)t19) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB27;

LAB28:    t36 = *((unsigned int *)t24);
    t37 = *((unsigned int *)t30);
    *((unsigned int *)t24) = (t36 | t37);
    t38 = (t13 + 4);
    t39 = (t19 + 4);
    t40 = *((unsigned int *)t13);
    t41 = (~(t40));
    t42 = *((unsigned int *)t38);
    t43 = (~(t42));
    t44 = *((unsigned int *)t19);
    t45 = (~(t44));
    t46 = *((unsigned int *)t39);
    t47 = (~(t46));
    t48 = (t41 & t43);
    t49 = (t45 & t47);
    t50 = (~(t48));
    t51 = (~(t49));
    t52 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t52 & t50);
    t53 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t53 & t51);
    t54 = *((unsigned int *)t24);
    *((unsigned int *)t24) = (t54 & t50);
    t55 = *((unsigned int *)t24);
    *((unsigned int *)t24) = (t55 & t51);
    goto LAB30;

LAB31:    xsi_set_current_line(45, ng0);

LAB34:    xsi_set_current_line(46, ng0);
    t62 = (t0 + 2952);
    t63 = (t62 + 56U);
    t64 = *((char **)t63);
    t65 = ((char*)((ng2)));
    memset(t66, 0, 8);
    t67 = (t64 + 4);
    t68 = (t65 + 4);
    t69 = *((unsigned int *)t64);
    t70 = *((unsigned int *)t65);
    t71 = (t69 ^ t70);
    t72 = *((unsigned int *)t67);
    t73 = *((unsigned int *)t68);
    t74 = (t72 ^ t73);
    t75 = (t71 | t74);
    t76 = *((unsigned int *)t67);
    t77 = *((unsigned int *)t68);
    t78 = (t76 | t77);
    t79 = (~(t78));
    t80 = (t75 & t79);
    if (t80 != 0)
        goto LAB38;

LAB35:    if (t78 != 0)
        goto LAB37;

LAB36:    *((unsigned int *)t66) = 1;

LAB38:    t82 = (t66 + 4);
    t83 = *((unsigned int *)t82);
    t84 = (~(t83));
    t85 = *((unsigned int *)t66);
    t86 = (t85 & t84);
    t87 = (t86 != 0);
    if (t87 > 0)
        goto LAB39;

LAB40:    xsi_set_current_line(52, ng0);

LAB43:    xsi_set_current_line(53, ng0);
    t2 = (t0 + 2952);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t13, 0, 8);
    xsi_vlog_unsigned_add(t13, 4, t4, 4, t5, 4);
    t11 = (t0 + 2952);
    xsi_vlogvar_wait_assign_value(t11, t13, 0, 0, 4, 0LL);
    xsi_set_current_line(54, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2792);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB41:    goto LAB33;

LAB37:    t81 = (t66 + 4);
    *((unsigned int *)t66) = 1;
    *((unsigned int *)t81) = 1;
    goto LAB38;

LAB39:    xsi_set_current_line(47, ng0);

LAB42:    xsi_set_current_line(48, ng0);
    t88 = ((char*)((ng3)));
    t89 = (t0 + 2952);
    xsi_vlogvar_wait_assign_value(t89, t88, 0, 0, 4, 0LL);
    xsi_set_current_line(49, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 2792);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    goto LAB41;

LAB44:    *((unsigned int *)t13) = 1;
    goto LAB47;

LAB48:    *((unsigned int *)t19) = 1;
    goto LAB51;

LAB50:    t11 = (t19 + 4);
    *((unsigned int *)t19) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB51;

LAB52:    t23 = (t0 + 2392U);
    t28 = *((char **)t23);
    memset(t24, 0, 8);
    t23 = (t28 + 4);
    t25 = *((unsigned int *)t23);
    t26 = (~(t25));
    t27 = *((unsigned int *)t28);
    t31 = (t27 & t26);
    t32 = (t31 & 1U);
    if (t32 != 0)
        goto LAB55;

LAB56:    if (*((unsigned int *)t23) != 0)
        goto LAB57;

LAB58:    t33 = *((unsigned int *)t19);
    t34 = *((unsigned int *)t24);
    t35 = (t33 & t34);
    *((unsigned int *)t66) = t35;
    t30 = (t19 + 4);
    t38 = (t24 + 4);
    t39 = (t66 + 4);
    t36 = *((unsigned int *)t30);
    t37 = *((unsigned int *)t38);
    t40 = (t36 | t37);
    *((unsigned int *)t39) = t40;
    t41 = *((unsigned int *)t39);
    t42 = (t41 != 0);
    if (t42 == 1)
        goto LAB59;

LAB60:
LAB61:    goto LAB54;

LAB55:    *((unsigned int *)t24) = 1;
    goto LAB58;

LAB57:    t29 = (t24 + 4);
    *((unsigned int *)t24) = 1;
    *((unsigned int *)t29) = 1;
    goto LAB58;

LAB59:    t43 = *((unsigned int *)t66);
    t44 = *((unsigned int *)t39);
    *((unsigned int *)t66) = (t43 | t44);
    t56 = (t19 + 4);
    t62 = (t24 + 4);
    t45 = *((unsigned int *)t19);
    t46 = (~(t45));
    t47 = *((unsigned int *)t56);
    t50 = (~(t47));
    t51 = *((unsigned int *)t24);
    t52 = (~(t51));
    t53 = *((unsigned int *)t62);
    t54 = (~(t53));
    t48 = (t46 & t50);
    t49 = (t52 & t54);
    t55 = (~(t48));
    t57 = (~(t49));
    t58 = *((unsigned int *)t39);
    *((unsigned int *)t39) = (t58 & t55);
    t59 = *((unsigned int *)t39);
    *((unsigned int *)t39) = (t59 & t57);
    t60 = *((unsigned int *)t66);
    *((unsigned int *)t66) = (t60 & t55);
    t61 = *((unsigned int *)t66);
    *((unsigned int *)t66) = (t61 & t57);
    goto LAB61;

LAB62:    xsi_set_current_line(58, ng0);

LAB65:    xsi_set_current_line(59, ng0);
    t64 = (t0 + 2952);
    t65 = (t64 + 56U);
    t67 = *((char **)t65);
    t68 = ((char*)((ng4)));
    memset(t90, 0, 8);
    t81 = (t67 + 4);
    t82 = (t68 + 4);
    t74 = *((unsigned int *)t67);
    t75 = *((unsigned int *)t68);
    t76 = (t74 ^ t75);
    t77 = *((unsigned int *)t81);
    t78 = *((unsigned int *)t82);
    t79 = (t77 ^ t78);
    t80 = (t76 | t79);
    t83 = *((unsigned int *)t81);
    t84 = *((unsigned int *)t82);
    t85 = (t83 | t84);
    t86 = (~(t85));
    t87 = (t80 & t86);
    if (t87 != 0)
        goto LAB69;

LAB66:    if (t85 != 0)
        goto LAB68;

LAB67:    *((unsigned int *)t90) = 1;

LAB69:    t89 = (t90 + 4);
    t91 = *((unsigned int *)t89);
    t92 = (~(t91));
    t93 = *((unsigned int *)t90);
    t94 = (t93 & t92);
    t95 = (t94 != 0);
    if (t95 > 0)
        goto LAB70;

LAB71:    xsi_set_current_line(65, ng0);

LAB74:    xsi_set_current_line(66, ng0);
    t2 = (t0 + 2952);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t13, 0, 8);
    xsi_vlog_unsigned_minus(t13, 4, t4, 4, t5, 4);
    t11 = (t0 + 2952);
    xsi_vlogvar_wait_assign_value(t11, t13, 0, 0, 4, 0LL);
    xsi_set_current_line(67, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2792);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB72:    goto LAB64;

LAB68:    t88 = (t90 + 4);
    *((unsigned int *)t90) = 1;
    *((unsigned int *)t88) = 1;
    goto LAB69;

LAB70:    xsi_set_current_line(60, ng0);

LAB73:    xsi_set_current_line(61, ng0);
    t96 = ((char*)((ng1)));
    t97 = (t0 + 2952);
    xsi_vlogvar_wait_assign_value(t97, t96, 0, 0, 4, 0LL);
    xsi_set_current_line(62, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 2792);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    goto LAB72;

}


extern void work_m_00000000003320656730_0704922496_init()
{
	static char *pe[] = {(void *)Always_33_0};
	xsi_register_didat("work_m_00000000003320656730_0704922496", "isim/shiyan13Test_isim_beh.exe.sim/work/m_00000000003320656730_0704922496.didat");
	xsi_register_executes(pe);
}
