/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/ISE/program/test23.2/xiaodou.v";
static unsigned int ng1[] = {0U, 0U};
static int ng2[] = {0, 0};
static int ng3[] = {1, 0};
static unsigned int ng4[] = {3U, 0U};
static unsigned int ng5[] = {1U, 0U};
static unsigned int ng6[] = {2U, 0U};
static unsigned int ng7[] = {4U, 0U};
static unsigned int ng8[] = {5U, 0U};



static void Initial_26_0(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(27, ng0);

LAB2:    xsi_set_current_line(28, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 1584);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 3);
    xsi_set_current_line(29, ng0);
    t1 = ((char*)((ng2)));
    t2 = (t0 + 1492);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 1);

LAB1:    return;
}

static void Always_31_1(char *t0)
{
    char t6[8];
    char t30[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    char *t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    char *t45;
    char *t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    char *t52;
    char *t53;
    int t54;

LAB0:    t1 = (t0 + 2252U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(31, ng0);
    t2 = (t0 + 2448);
    *((int *)t2) = 1;
    t3 = (t0 + 2280);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(33, ng0);

LAB5:    xsi_set_current_line(34, ng0);
    t4 = (t0 + 1264U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng3)));
    memset(t6, 0, 8);
    t7 = (t5 + 4);
    t8 = (t4 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t4);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB9;

LAB6:    if (t18 != 0)
        goto LAB8;

LAB7:    *((unsigned int *)t6) = 1;

LAB9:    t22 = (t6 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 != 0);
    if (t27 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(42, ng0);

LAB21:    xsi_set_current_line(43, ng0);
    t2 = (t0 + 1584);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);

LAB22:    t5 = ((char*)((ng1)));
    t54 = xsi_vlog_unsigned_case_compare(t4, 3, t5, 3);
    if (t54 == 1)
        goto LAB23;

LAB24:    t2 = ((char*)((ng5)));
    t54 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t54 == 1)
        goto LAB25;

LAB26:    t2 = ((char*)((ng6)));
    t54 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t54 == 1)
        goto LAB27;

LAB28:    t2 = ((char*)((ng4)));
    t54 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t54 == 1)
        goto LAB29;

LAB30:    t2 = ((char*)((ng7)));
    t54 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t54 == 1)
        goto LAB31;

LAB32:    t2 = ((char*)((ng8)));
    t54 = xsi_vlog_unsigned_case_compare(t4, 3, t2, 3);
    if (t54 == 1)
        goto LAB33;

LAB34:
LAB35:    xsi_set_current_line(52, ng0);
    t2 = (t0 + 1584);
    t3 = (t2 + 36U);
    t5 = *((char **)t3);

LAB114:    t7 = ((char*)((ng1)));
    t54 = xsi_vlog_unsigned_case_compare(t5, 3, t7, 3);
    if (t54 == 1)
        goto LAB115;

LAB116:    t2 = ((char*)((ng5)));
    t54 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 3);
    if (t54 == 1)
        goto LAB117;

LAB118:    t2 = ((char*)((ng6)));
    t54 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 3);
    if (t54 == 1)
        goto LAB119;

LAB120:    t2 = ((char*)((ng4)));
    t54 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 3);
    if (t54 == 1)
        goto LAB121;

LAB122:    t2 = ((char*)((ng7)));
    t54 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 3);
    if (t54 == 1)
        goto LAB123;

LAB124:    t2 = ((char*)((ng8)));
    t54 = xsi_vlog_unsigned_case_compare(t5, 3, t2, 3);
    if (t54 == 1)
        goto LAB125;

LAB126:
LAB127:
LAB12:    goto LAB2;

LAB8:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(35, ng0);

LAB13:    xsi_set_current_line(36, ng0);
    t28 = (t0 + 1080U);
    t29 = *((char **)t28);
    t28 = ((char*)((ng2)));
    memset(t30, 0, 8);
    t31 = (t29 + 4);
    t32 = (t28 + 4);
    t33 = *((unsigned int *)t29);
    t34 = *((unsigned int *)t28);
    t35 = (t33 ^ t34);
    t36 = *((unsigned int *)t31);
    t37 = *((unsigned int *)t32);
    t38 = (t36 ^ t37);
    t39 = (t35 | t38);
    t40 = *((unsigned int *)t31);
    t41 = *((unsigned int *)t32);
    t42 = (t40 | t41);
    t43 = (~(t42));
    t44 = (t39 & t43);
    if (t44 != 0)
        goto LAB17;

LAB14:    if (t42 != 0)
        goto LAB16;

LAB15:    *((unsigned int *)t30) = 1;

LAB17:    t46 = (t30 + 4);
    t47 = *((unsigned int *)t46);
    t48 = (~(t47));
    t49 = *((unsigned int *)t30);
    t50 = (t49 & t48);
    t51 = (t50 != 0);
    if (t51 > 0)
        goto LAB18;

LAB19:    xsi_set_current_line(39, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 1584);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 3, 0LL);

LAB20:    goto LAB12;

LAB16:    t45 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t45) = 1;
    goto LAB17;

LAB18:    xsi_set_current_line(37, ng0);
    t52 = ((char*)((ng1)));
    t53 = (t0 + 1584);
    xsi_vlogvar_wait_assign_value(t53, t52, 0, 0, 3, 0LL);
    goto LAB20;

LAB23:    xsi_set_current_line(44, ng0);
    t7 = (t0 + 1080U);
    t8 = *((char **)t7);
    memset(t30, 0, 8);
    t7 = (t8 + 4);
    t9 = *((unsigned int *)t7);
    t10 = (~(t9));
    t11 = *((unsigned int *)t8);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB36;

LAB37:    if (*((unsigned int *)t7) != 0)
        goto LAB38;

LAB39:    t22 = (t30 + 4);
    t14 = *((unsigned int *)t30);
    t15 = *((unsigned int *)t22);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB40;

LAB41:    t17 = *((unsigned int *)t30);
    t18 = (~(t17));
    t19 = *((unsigned int *)t22);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB42;

LAB43:    if (*((unsigned int *)t22) > 0)
        goto LAB44;

LAB45:    if (*((unsigned int *)t30) > 0)
        goto LAB46;

LAB47:    memcpy(t6, t29, 8);

LAB48:    t31 = (t0 + 1492);
    xsi_vlogvar_wait_assign_value(t31, t6, 0, 0, 1, 0LL);
    goto LAB35;

LAB25:    xsi_set_current_line(45, ng0);
    t3 = (t0 + 1080U);
    t5 = *((char **)t3);
    memset(t30, 0, 8);
    t3 = (t5 + 4);
    t9 = *((unsigned int *)t3);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB49;

LAB50:    if (*((unsigned int *)t3) != 0)
        goto LAB51;

LAB52:    t8 = (t30 + 4);
    t14 = *((unsigned int *)t30);
    t15 = *((unsigned int *)t8);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB53;

LAB54:    t17 = *((unsigned int *)t30);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB55;

LAB56:    if (*((unsigned int *)t8) > 0)
        goto LAB57;

LAB58:    if (*((unsigned int *)t30) > 0)
        goto LAB59;

LAB60:    memcpy(t6, t22, 8);

LAB61:    t28 = (t0 + 1492);
    xsi_vlogvar_wait_assign_value(t28, t6, 0, 0, 1, 0LL);
    goto LAB35;

LAB27:    xsi_set_current_line(46, ng0);
    t3 = (t0 + 1080U);
    t5 = *((char **)t3);
    memset(t30, 0, 8);
    t3 = (t5 + 4);
    t9 = *((unsigned int *)t3);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB62;

LAB63:    if (*((unsigned int *)t3) != 0)
        goto LAB64;

LAB65:    t8 = (t30 + 4);
    t14 = *((unsigned int *)t30);
    t15 = *((unsigned int *)t8);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB66;

LAB67:    t17 = *((unsigned int *)t30);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB68;

LAB69:    if (*((unsigned int *)t8) > 0)
        goto LAB70;

LAB71:    if (*((unsigned int *)t30) > 0)
        goto LAB72;

LAB73:    memcpy(t6, t22, 8);

LAB74:    t28 = (t0 + 1492);
    xsi_vlogvar_wait_assign_value(t28, t6, 0, 0, 1, 0LL);
    goto LAB35;

LAB29:    xsi_set_current_line(47, ng0);
    t3 = (t0 + 1080U);
    t5 = *((char **)t3);
    memset(t30, 0, 8);
    t3 = (t5 + 4);
    t9 = *((unsigned int *)t3);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB75;

LAB76:    if (*((unsigned int *)t3) != 0)
        goto LAB77;

LAB78:    t8 = (t30 + 4);
    t14 = *((unsigned int *)t30);
    t15 = *((unsigned int *)t8);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB79;

LAB80:    t17 = *((unsigned int *)t30);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB81;

LAB82:    if (*((unsigned int *)t8) > 0)
        goto LAB83;

LAB84:    if (*((unsigned int *)t30) > 0)
        goto LAB85;

LAB86:    memcpy(t6, t22, 8);

LAB87:    t28 = (t0 + 1492);
    xsi_vlogvar_wait_assign_value(t28, t6, 0, 0, 1, 0LL);
    goto LAB35;

LAB31:    xsi_set_current_line(48, ng0);
    t3 = (t0 + 1080U);
    t5 = *((char **)t3);
    memset(t30, 0, 8);
    t3 = (t5 + 4);
    t9 = *((unsigned int *)t3);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB88;

LAB89:    if (*((unsigned int *)t3) != 0)
        goto LAB90;

LAB91:    t8 = (t30 + 4);
    t14 = *((unsigned int *)t30);
    t15 = *((unsigned int *)t8);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB92;

LAB93:    t17 = *((unsigned int *)t30);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB94;

LAB95:    if (*((unsigned int *)t8) > 0)
        goto LAB96;

LAB97:    if (*((unsigned int *)t30) > 0)
        goto LAB98;

LAB99:    memcpy(t6, t22, 8);

LAB100:    t28 = (t0 + 1492);
    xsi_vlogvar_wait_assign_value(t28, t6, 0, 0, 1, 0LL);
    goto LAB35;

LAB33:    xsi_set_current_line(49, ng0);
    t3 = (t0 + 1080U);
    t5 = *((char **)t3);
    memset(t30, 0, 8);
    t3 = (t5 + 4);
    t9 = *((unsigned int *)t3);
    t10 = (~(t9));
    t11 = *((unsigned int *)t5);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB101;

LAB102:    if (*((unsigned int *)t3) != 0)
        goto LAB103;

LAB104:    t8 = (t30 + 4);
    t14 = *((unsigned int *)t30);
    t15 = *((unsigned int *)t8);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB105;

LAB106:    t17 = *((unsigned int *)t30);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB107;

LAB108:    if (*((unsigned int *)t8) > 0)
        goto LAB109;

LAB110:    if (*((unsigned int *)t30) > 0)
        goto LAB111;

LAB112:    memcpy(t6, t22, 8);

LAB113:    t28 = (t0 + 1492);
    xsi_vlogvar_wait_assign_value(t28, t6, 0, 0, 1, 0LL);
    goto LAB35;

LAB36:    *((unsigned int *)t30) = 1;
    goto LAB39;

LAB38:    t21 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB39;

LAB40:    t28 = ((char*)((ng2)));
    goto LAB41;

LAB42:    t29 = ((char*)((ng2)));
    goto LAB43;

LAB44:    xsi_vlog_unsigned_bit_combine(t6, 32, t28, 32, t29, 32);
    goto LAB48;

LAB46:    memcpy(t6, t28, 8);
    goto LAB48;

LAB49:    *((unsigned int *)t30) = 1;
    goto LAB52;

LAB51:    t7 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t7) = 1;
    goto LAB52;

LAB53:    t21 = ((char*)((ng3)));
    goto LAB54;

LAB55:    t22 = ((char*)((ng2)));
    goto LAB56;

LAB57:    xsi_vlog_unsigned_bit_combine(t6, 32, t21, 32, t22, 32);
    goto LAB61;

LAB59:    memcpy(t6, t21, 8);
    goto LAB61;

LAB62:    *((unsigned int *)t30) = 1;
    goto LAB65;

LAB64:    t7 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t7) = 1;
    goto LAB65;

LAB66:    t21 = ((char*)((ng2)));
    goto LAB67;

LAB68:    t22 = ((char*)((ng2)));
    goto LAB69;

LAB70:    xsi_vlog_unsigned_bit_combine(t6, 32, t21, 32, t22, 32);
    goto LAB74;

LAB72:    memcpy(t6, t21, 8);
    goto LAB74;

LAB75:    *((unsigned int *)t30) = 1;
    goto LAB78;

LAB77:    t7 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t7) = 1;
    goto LAB78;

LAB79:    t21 = ((char*)((ng3)));
    goto LAB80;

LAB81:    t22 = ((char*)((ng3)));
    goto LAB82;

LAB83:    xsi_vlog_unsigned_bit_combine(t6, 32, t21, 32, t22, 32);
    goto LAB87;

LAB85:    memcpy(t6, t21, 8);
    goto LAB87;

LAB88:    *((unsigned int *)t30) = 1;
    goto LAB91;

LAB90:    t7 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t7) = 1;
    goto LAB91;

LAB92:    t21 = ((char*)((ng3)));
    goto LAB93;

LAB94:    t22 = ((char*)((ng2)));
    goto LAB95;

LAB96:    xsi_vlog_unsigned_bit_combine(t6, 32, t21, 32, t22, 32);
    goto LAB100;

LAB98:    memcpy(t6, t21, 8);
    goto LAB100;

LAB101:    *((unsigned int *)t30) = 1;
    goto LAB104;

LAB103:    t7 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t7) = 1;
    goto LAB104;

LAB105:    t21 = ((char*)((ng3)));
    goto LAB106;

LAB107:    t22 = ((char*)((ng2)));
    goto LAB108;

LAB109:    xsi_vlog_unsigned_bit_combine(t6, 32, t21, 32, t22, 32);
    goto LAB113;

LAB111:    memcpy(t6, t21, 8);
    goto LAB113;

LAB115:    xsi_set_current_line(53, ng0);
    t8 = (t0 + 1080U);
    t21 = *((char **)t8);
    memset(t30, 0, 8);
    t8 = (t21 + 4);
    t9 = *((unsigned int *)t8);
    t10 = (~(t9));
    t11 = *((unsigned int *)t21);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB128;

LAB129:    if (*((unsigned int *)t8) != 0)
        goto LAB130;

LAB131:    t28 = (t30 + 4);
    t14 = *((unsigned int *)t30);
    t15 = *((unsigned int *)t28);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB132;

LAB133:    t17 = *((unsigned int *)t30);
    t18 = (~(t17));
    t19 = *((unsigned int *)t28);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB134;

LAB135:    if (*((unsigned int *)t28) > 0)
        goto LAB136;

LAB137:    if (*((unsigned int *)t30) > 0)
        goto LAB138;

LAB139:    memcpy(t6, t31, 8);

LAB140:    t32 = (t0 + 1584);
    xsi_vlogvar_wait_assign_value(t32, t6, 0, 0, 3, 0LL);
    goto LAB127;

LAB117:    xsi_set_current_line(54, ng0);
    t3 = (t0 + 1080U);
    t7 = *((char **)t3);
    memset(t30, 0, 8);
    t3 = (t7 + 4);
    t9 = *((unsigned int *)t3);
    t10 = (~(t9));
    t11 = *((unsigned int *)t7);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB141;

LAB142:    if (*((unsigned int *)t3) != 0)
        goto LAB143;

LAB144:    t21 = (t30 + 4);
    t14 = *((unsigned int *)t30);
    t15 = *((unsigned int *)t21);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB145;

LAB146:    t17 = *((unsigned int *)t30);
    t18 = (~(t17));
    t19 = *((unsigned int *)t21);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB147;

LAB148:    if (*((unsigned int *)t21) > 0)
        goto LAB149;

LAB150:    if (*((unsigned int *)t30) > 0)
        goto LAB151;

LAB152:    memcpy(t6, t28, 8);

LAB153:    t29 = (t0 + 1584);
    xsi_vlogvar_wait_assign_value(t29, t6, 0, 0, 3, 0LL);
    goto LAB127;

LAB119:    xsi_set_current_line(55, ng0);
    t3 = (t0 + 1080U);
    t7 = *((char **)t3);
    memset(t30, 0, 8);
    t3 = (t7 + 4);
    t9 = *((unsigned int *)t3);
    t10 = (~(t9));
    t11 = *((unsigned int *)t7);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB154;

LAB155:    if (*((unsigned int *)t3) != 0)
        goto LAB156;

LAB157:    t21 = (t30 + 4);
    t14 = *((unsigned int *)t30);
    t15 = *((unsigned int *)t21);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB158;

LAB159:    t17 = *((unsigned int *)t30);
    t18 = (~(t17));
    t19 = *((unsigned int *)t21);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB160;

LAB161:    if (*((unsigned int *)t21) > 0)
        goto LAB162;

LAB163:    if (*((unsigned int *)t30) > 0)
        goto LAB164;

LAB165:    memcpy(t6, t28, 8);

LAB166:    t29 = (t0 + 1584);
    xsi_vlogvar_wait_assign_value(t29, t6, 0, 0, 3, 0LL);
    goto LAB127;

LAB121:    xsi_set_current_line(56, ng0);
    t3 = (t0 + 1080U);
    t7 = *((char **)t3);
    memset(t30, 0, 8);
    t3 = (t7 + 4);
    t9 = *((unsigned int *)t3);
    t10 = (~(t9));
    t11 = *((unsigned int *)t7);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB167;

LAB168:    if (*((unsigned int *)t3) != 0)
        goto LAB169;

LAB170:    t21 = (t30 + 4);
    t14 = *((unsigned int *)t30);
    t15 = *((unsigned int *)t21);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB171;

LAB172:    t17 = *((unsigned int *)t30);
    t18 = (~(t17));
    t19 = *((unsigned int *)t21);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB173;

LAB174:    if (*((unsigned int *)t21) > 0)
        goto LAB175;

LAB176:    if (*((unsigned int *)t30) > 0)
        goto LAB177;

LAB178:    memcpy(t6, t28, 8);

LAB179:    t29 = (t0 + 1584);
    xsi_vlogvar_wait_assign_value(t29, t6, 0, 0, 3, 0LL);
    goto LAB127;

LAB123:    xsi_set_current_line(57, ng0);
    t3 = (t0 + 1080U);
    t7 = *((char **)t3);
    memset(t30, 0, 8);
    t3 = (t7 + 4);
    t9 = *((unsigned int *)t3);
    t10 = (~(t9));
    t11 = *((unsigned int *)t7);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB180;

LAB181:    if (*((unsigned int *)t3) != 0)
        goto LAB182;

LAB183:    t21 = (t30 + 4);
    t14 = *((unsigned int *)t30);
    t15 = *((unsigned int *)t21);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB184;

LAB185:    t17 = *((unsigned int *)t30);
    t18 = (~(t17));
    t19 = *((unsigned int *)t21);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB186;

LAB187:    if (*((unsigned int *)t21) > 0)
        goto LAB188;

LAB189:    if (*((unsigned int *)t30) > 0)
        goto LAB190;

LAB191:    memcpy(t6, t28, 8);

LAB192:    t29 = (t0 + 1584);
    xsi_vlogvar_wait_assign_value(t29, t6, 0, 0, 3, 0LL);
    goto LAB127;

LAB125:    xsi_set_current_line(58, ng0);
    t3 = (t0 + 1080U);
    t7 = *((char **)t3);
    memset(t30, 0, 8);
    t3 = (t7 + 4);
    t9 = *((unsigned int *)t3);
    t10 = (~(t9));
    t11 = *((unsigned int *)t7);
    t12 = (t11 & t10);
    t13 = (t12 & 1U);
    if (t13 != 0)
        goto LAB193;

LAB194:    if (*((unsigned int *)t3) != 0)
        goto LAB195;

LAB196:    t21 = (t30 + 4);
    t14 = *((unsigned int *)t30);
    t15 = *((unsigned int *)t21);
    t16 = (t14 || t15);
    if (t16 > 0)
        goto LAB197;

LAB198:    t17 = *((unsigned int *)t30);
    t18 = (~(t17));
    t19 = *((unsigned int *)t21);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB199;

LAB200:    if (*((unsigned int *)t21) > 0)
        goto LAB201;

LAB202:    if (*((unsigned int *)t30) > 0)
        goto LAB203;

LAB204:    memcpy(t6, t28, 8);

LAB205:    t29 = (t0 + 1584);
    xsi_vlogvar_wait_assign_value(t29, t6, 0, 0, 3, 0LL);
    goto LAB127;

LAB128:    *((unsigned int *)t30) = 1;
    goto LAB131;

LAB130:    t22 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t22) = 1;
    goto LAB131;

LAB132:    t29 = ((char*)((ng5)));
    goto LAB133;

LAB134:    t31 = ((char*)((ng1)));
    goto LAB135;

LAB136:    xsi_vlog_unsigned_bit_combine(t6, 3, t29, 3, t31, 3);
    goto LAB140;

LAB138:    memcpy(t6, t29, 8);
    goto LAB140;

LAB141:    *((unsigned int *)t30) = 1;
    goto LAB144;

LAB143:    t8 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB144;

LAB145:    t22 = ((char*)((ng4)));
    goto LAB146;

LAB147:    t28 = ((char*)((ng6)));
    goto LAB148;

LAB149:    xsi_vlog_unsigned_bit_combine(t6, 3, t22, 3, t28, 3);
    goto LAB153;

LAB151:    memcpy(t6, t22, 8);
    goto LAB153;

LAB154:    *((unsigned int *)t30) = 1;
    goto LAB157;

LAB156:    t8 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB157;

LAB158:    t22 = ((char*)((ng5)));
    goto LAB159;

LAB160:    t28 = ((char*)((ng1)));
    goto LAB161;

LAB162:    xsi_vlog_unsigned_bit_combine(t6, 3, t22, 3, t28, 3);
    goto LAB166;

LAB164:    memcpy(t6, t22, 8);
    goto LAB166;

LAB167:    *((unsigned int *)t30) = 1;
    goto LAB170;

LAB169:    t8 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB170;

LAB171:    t22 = ((char*)((ng4)));
    goto LAB172;

LAB173:    t28 = ((char*)((ng7)));
    goto LAB174;

LAB175:    xsi_vlog_unsigned_bit_combine(t6, 3, t22, 3, t28, 3);
    goto LAB179;

LAB177:    memcpy(t6, t22, 8);
    goto LAB179;

LAB180:    *((unsigned int *)t30) = 1;
    goto LAB183;

LAB182:    t8 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB183;

LAB184:    t22 = ((char*)((ng8)));
    goto LAB185;

LAB186:    t28 = ((char*)((ng1)));
    goto LAB187;

LAB188:    xsi_vlog_unsigned_bit_combine(t6, 3, t22, 3, t28, 3);
    goto LAB192;

LAB190:    memcpy(t6, t22, 8);
    goto LAB192;

LAB193:    *((unsigned int *)t30) = 1;
    goto LAB196;

LAB195:    t8 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB196;

LAB197:    t22 = ((char*)((ng4)));
    goto LAB198;

LAB199:    t28 = ((char*)((ng7)));
    goto LAB200;

LAB201:    xsi_vlog_unsigned_bit_combine(t6, 3, t22, 3, t28, 3);
    goto LAB205;

LAB203:    memcpy(t6, t22, 8);
    goto LAB205;

}


extern void work_m_00000000003074071278_2132334303_init()
{
	static char *pe[] = {(void *)Initial_26_0,(void *)Always_31_1};
	xsi_register_didat("work_m_00000000003074071278_2132334303", "isim/test_isim_beh.exe.sim/work/m_00000000003074071278_2132334303.didat");
	xsi_register_executes(pe);
}
